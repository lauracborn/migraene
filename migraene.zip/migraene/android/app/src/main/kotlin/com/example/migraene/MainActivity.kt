package com.example.migraene

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
