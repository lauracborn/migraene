import 'package:flutter/material.dart';
import 'package:migraene/screens/plus_screen.dart';

class TriggerScreen extends StatefulWidget {
  const TriggerScreen({Key? key}) : super(key: key);

  static String trigger = '';

  @override
  State<TriggerScreen> createState() => _TriggerScreenState();
}

class _TriggerScreenState extends State<TriggerScreen> {

  Color _containerColor1 = Color(0xffffffff);
  Color _containerColor2 = Color(0xffffffff);
  Color _containerColor3 = Color(0xffffffff);
  Color _containerColor4 = Color(0xffffffff);
  Color _containerColor5 = Color(0xffffffff);
  Color _containerColor6 = Color(0xffffffff);
  bool tapped1 = false;
  bool tapped2 = false;
  bool tapped3 = false;
  bool tapped4 = false;
  bool tapped5 = false;
  bool tapped6 = false;

  bool oneistapped = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Transform.scale(
            scale: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: IconButton(
                icon: new Image.asset(
                  'assets/icons/back.jpg',
                  height: 15,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                  if(tapped1 == true) {
                    TriggerScreen.trigger = 'Stress';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                  if(tapped2 == true) {
                    TriggerScreen.trigger = 'Wetter';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                  if(tapped3 == true) {
                    TriggerScreen.trigger = 'Schlafmangel';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                  if(tapped4 == true) {
                    TriggerScreen.trigger = 'Alkohol';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                  if(tapped5 == true) {
                    TriggerScreen.trigger = 'Ernährung';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                  if(tapped6 == true) {
                    TriggerScreen.trigger = 'Keine';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                }
              ),
            )),
      ),
      body: Stack(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment(-1, 1),
                end: Alignment(1, -1),
                colors: <Color>[
                  Color(0xff90f9ff),
                  Color(0xff9df4ff),
                  Color(0xffb9edff),
                  Color(0xffd7e5ff),
                  Color(0xffefdeff),
                  Color(0xffffdaf6),
                ],
              ),
            ),
          ),
          Container(
            width: 400,
            child: Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.only(top: 140.0, left: 50),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('trigger',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 38,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                        )),
                    Text('was ist Schuld?',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 25,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                          height: 0.9,
                        )),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Stack(
              children: <Widget>[
                Container(
                  height: 520,
                  width: MediaQuery.of(context).size.width,
                  decoration: new BoxDecoration(
                    color: Color(0xff000000),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(40),
                      topLeft: Radius.circular(40),
                    ),
                  ),
                  child: ListView(
                    children: <Widget>[
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor1,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Stress',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped1 == false) {
                                tapped1 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor1 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped1 == true) {
                                oneistapped = false;
                                tapped1 = false;
                                setState(() {
                                  _containerColor1 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor2,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Wetter',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped2 == false) {
                                tapped2 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor2 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped2 == true) {
                                oneistapped = false;
                                tapped2 = false;
                                setState(() {
                                  _containerColor2 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor3,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Schlafmangel',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped3 == false) {
                                tapped3 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor3 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped3 == true) {
                                oneistapped = false;
                                tapped3 = false;
                                setState(() {
                                  _containerColor3 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor4,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Alkohol',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped4 == false) {
                                tapped4 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor4 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped4 == true) {
                                oneistapped = false;
                                tapped4 = false;
                                setState(() {
                                  _containerColor4 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor5,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Ernährung',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped5 == false) {
                                tapped5 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor5 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped5 == true) {
                                oneistapped = false;
                                tapped5 = false;
                                setState(() {
                                  _containerColor5 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor6,
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18, bottom: 30),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Keine',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(oneistapped == false) {
                              if(tapped6 == false) {
                                tapped6 = true;
                                oneistapped = true;
                                setState(() {
                                  _containerColor6 = Color(0xffdfbfff);
                                });
                              }
                            } else {
                              if(tapped6 == true) {
                                oneistapped = false;
                                tapped6 = false;
                                setState(() {
                                  _containerColor6 = Color(0xffffffff);
                                });
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );

  }
}
