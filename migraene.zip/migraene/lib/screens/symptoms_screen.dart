import 'package:flutter/material.dart';
import 'package:migraene/screens/plus_screen.dart';

class SymptomsScreen extends StatefulWidget {
  const SymptomsScreen({Key? key}) : super(key: key);

  static String symptoms = '';

  @override
  State<SymptomsScreen> createState() => _SymptomsScreenState();
}

class _SymptomsScreenState extends State<SymptomsScreen> {


  Color _containerColor1 = Color(0xffffffff);
  Color _containerColor2 = Color(0xffffffff);
  Color _containerColor3 = Color(0xffffffff);
  Color _containerColor4 = Color(0xffffffff);
  Color _containerColor5 = Color(0xffffffff);
  Color _containerColor6 = Color(0xffffffff);
  Color _containerColor7 = Color(0xffffffff);
  Color _containerColor8 = Color(0xffffffff);
  bool tapped1 = false;
  bool tapped2 = false;
  bool tapped3 = false;
  bool tapped4 = false;
  bool tapped5 = false;
  bool tapped6 = false;
  bool tapped7 = false;
  bool tapped8 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Transform.scale(
            scale: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: IconButton(
                icon: new Image.asset(
                  'assets/icons/back.jpg',
                  height: 15,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                  //ist das erste Feld angekreuzt, dann wird Sehstörungen an PlusScreen gesendet, ansonsten bleibt es bei default
                  if(tapped1 == true) {
                    SymptomsScreen.symptoms = 'Sehstörungen';
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PlusScreen()),
                    );
                  }
                }
              ),
            )
        ),
      ),
      body: Stack(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment(-1, 1),
                end: Alignment(1, -1),
                colors: <Color>[
                  Color(0xff90f9ff),
                  Color(0xff9df4ff),
                  Color(0xffb9edff),
                  Color(0xffd7e5ff),
                  Color(0xffefdeff),
                  Color(0xffffdaf6),
                ],
              ),
            ),
          ),

          Container(
            width: 400,
            child: Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.only(top: 140.0, left: 50),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('symptome',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 38,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                        )),
                    Text('wo drückt der Schuh?',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 25,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                          height: 0.9,
                        )),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Stack(
              children: <Widget>[
                Container(
                  height: 520,
                  width: MediaQuery.of(context).size.width,
                  decoration: new BoxDecoration(
                    color: Color(0xff000000),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(40),
                      topLeft: Radius.circular(40),
                    ),
                  ),
                  child: ListView(
                    children: <Widget>[
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor1,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Sehstörungen',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped1 == false) {
                              tapped1 = true;
                              setState(() {
                                _containerColor1 = Color(0xffdfbfff);
                              });
                            } else {
                              setState(() {
                                _containerColor1 = Color(0xffffffff);
                              });
                              tapped1 = false;
                            }
                          },
                        ),
                      ),

                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor2,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Lichtempfindlich',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped2 == false) {
                              tapped2 = true;
                              setState(() {
                                _containerColor2 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor2 = Color(0xffffffff);
                              });
                              tapped2 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor3,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Geräuschempfindlich',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped3 == false) {
                              tapped3 = true;
                              setState(() {
                                _containerColor3 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor3 = Color(0xffffffff);
                              });
                              tapped3 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor4,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Geruchsempfindlich',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped4 == false) {
                              tapped4 = true;
                              setState(() {
                                _containerColor4 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor4 = Color(0xffffffff);
                              });
                              tapped4 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor5,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Übelkeit',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped5 == false) {
                              tapped5 = true;
                              setState(() {
                                _containerColor5 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor5 = Color(0xffffffff);
                              });
                              tapped5 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor6,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Schüttelfrost',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped6 == false) {
                              tapped6 = true;
                              setState(() {
                                _containerColor6 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor6 = Color(0xffffffff);
                              });
                              tapped6 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor7,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Schwindel',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped7 == false) {
                              tapped7 = true;
                              setState(() {
                                _containerColor7 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor7 = Color(0xffffffff);
                              });
                              tapped7 = false;
                            }
                          },
                        ),
                      ),
                      Ink(
                        child: InkWell(
                          child: Container(
                            height: 70,
                            decoration: new BoxDecoration(
                              border: Border.all(
                                color: _containerColor8,
                                //color: Color(0xffffffff),
                                width:3,
                              ),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            margin: const EdgeInsets.only(left: 55, right: 55, top: 18, bottom: 30),
                            width: 300.0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 13.0),
                              child: new Text('Keine',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'Poppins-Thin',
                                  fontSize: 23,
                                  color: Color(0xffffffff),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          onTap: () {
                            if(tapped8 == false) {
                              tapped8 = true;
                              setState(() {
                                _containerColor8 = Color(0xffff66cc);
                              });
                            } else {
                              setState(() {
                                _containerColor8 = Color(0xffffffff);
                              });
                              tapped8 = false;
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
