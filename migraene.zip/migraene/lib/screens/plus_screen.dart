import 'package:flutter/material.dart';
import 'package:migraene/screens/schmerz_screen.dart';
import 'package:migraene/screens/symptoms_screen.dart';
import 'package:migraene/screens/trigger_screen.dart';
import 'package:migraene/screens/lokalisation_screen.dart';
import 'package:migraene/screens/medication_screen.dart';

import '../services/mabackend_service_provider.dart';
import '../services/model/migraeneanfall.dart';
import 'lokalisation_screen.dart';
import 'medication_screen.dart';

class PlusScreen extends StatefulWidget {

  const PlusScreen({Key? key}) : super(key: key);

  @override
  State<PlusScreen> createState() => _PlusScreenState();
}

class _PlusScreenState extends State<PlusScreen> {
  String setMedication = MedicationScreen.medication.toString();
  String setSymptoms = SymptomsScreen.symptoms.toString();
  String setTrigger = TriggerScreen.trigger.toString();
  String setSchmerzen = SchmerzScreen.schmerzen.toString();
  String setLokalisation = LokalisationScreen.lokalisation.toString();
  String dumm = 'Banane';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: <Widget>[
        Container(
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(-1, 1),
              end: Alignment(1, -1),
              colors: <Color>[
                Color(0xff90f9ff),
                Color(0xff9df4ff),
                Color(0xffb9edff),
                Color(0xffd7e5ff),
                Color(0xffefdeff),
                Color(0xffffdaf6),
              ],
            ),
          ),
        ),
        Container(
          width: 400,
          child: Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: const EdgeInsets.only(top: 140.0, left: 50),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(setTrigger,
                      style: TextStyle(
                        fontFamily: 'Poppins-Thin',
                        fontSize: 35,
                        color: Color(0xFF000000),
                        fontWeight: FontWeight.bold,
                      )),
                  Text('wieder migräne...',
                      style: TextStyle(
                        fontFamily: 'Poppins-Thin',
                        fontSize: 35,
                        color: Color(0xFF000000),
                        fontWeight: FontWeight.bold,
                        height: 0.9,
                      )),
                ],
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Stack(
            children: <Widget>[
              Container(
                height: 445,
                width: MediaQuery.of(context).size.width,
                decoration: new BoxDecoration(
                  color: Color(0xff000000),
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(40),
                    topLeft: Radius.circular(40),
                  ),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 30.0),
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 50.0),
                        height: 250.0,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SchmerzScreen(),
                                  ),
                                );
                              },
                              child: Container(
                                decoration: new BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xffffffff),
                                    width: 4,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                margin: const EdgeInsets.only(left: 55),
                                width: 220.0,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    new Image.asset(
                                      ''
                                      'assets/categories/schmerzen.png',
                                      scale: 1.6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Text(
                                        'Schmerzen',
                                        style: const TextStyle(
                                          color: Color(0xffffffff),
                                          fontSize: 16,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SymptomsScreen(),
                                  ),
                                );
                              },
                              child: Container(
                                decoration: new BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xffffffff),
                                    width: 4,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                margin: const EdgeInsets.only(left: 20),
                                width: 220.0,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    new Image.asset(
                                      'assets/categories/symptome.png',
                                      scale: 1.6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Text(
                                        'Symptome',
                                        style: const TextStyle(
                                          color: Color(0xffffffff),
                                          fontSize: 16,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => TriggerScreen(),
                                  ),
                                );
                              },
                              child: Container(
                                decoration: new BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xffffffff),
                                    width: 4,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                margin: const EdgeInsets.only(left: 20),
                                width: 220.0,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    new Image.asset(
                                      'assets/categories/trigger.png',
                                      scale: 1.6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Text(
                                        'Trigger',
                                        style: const TextStyle(
                                          color: Color(0xffffffff),
                                          fontSize: 16,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => LokalisationScreen(),
                                  ),
                                );
                              },
                              child: Container(
                                decoration: new BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xffffffff),
                                    width: 4,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                margin: const EdgeInsets.only(left: 20),
                                width: 220.0,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    new Image.asset(
                                      'assets/categories/lokalisation.png',
                                      scale: 1.6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Text(
                                        'Lokalisation',
                                        style: const TextStyle(
                                          color: Color(0xffffffff),
                                          fontSize: 16,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MedicationScreen(),
                                  ),
                                );
                              },
                              child: Container(
                                decoration: new BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xffffffff),
                                    width: 4,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                                margin: const EdgeInsets.only(left: 20, right: 55),
                                width: 220.0,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    new Image.asset(
                                      'assets/categories/medikamente.png',
                                      scale: 1.6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Text(
                                        'Medikamente',
                                        style: const TextStyle(
                                          color: Color(0xffffffff),
                                          fontSize: 16,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        textStyle:
                        const TextStyle(fontFamily: 'Poppins-SemiBold'),
                        shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.circular(18), // <-- Radius
                        ),
                        backgroundColor: Colors.black,
                        side:
                        BorderSide(color: Color(0xffffffff), width: 3),
                      ),
                      onPressed: () async {
                        Migraeneanfall anfall = Migraeneanfall(
                          id: 0,
                          datum: DateTime.now(),
                          hasSymptome: [],
                          lokalisation: setLokalisation,
                          medikamente: setMedication,
                          schmerzen: setSchmerzen,
                          trigger: setTrigger,
                        );

                        bool result =
                        await MABackendServiceProvider.createObject<Migraeneanfall>(
                          data: anfall,
                          toJson: migraeneanfallToJson,
                          resourcePath: "migraeneanfall.json",
                        );
                        setState(() {
                          // update der Liste
                        });
                      },
                      child: Text("speichern"),
                    ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
