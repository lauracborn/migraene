import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                colors: <Color>[
                  Color(0xffffdaf6),
                  Color(0xfff5ddff),
                  Color(0xffe6e1ff),
                  Color(0xffd3e6ff),
                  Color(0xffbdecff),
                  Color(0xffa8f1ff),
                  Color(0xff97f6ff),
                  Color(0xff90f9ff),
                ],
              ),
            ),
          ),
          /*Container(
            width: 400,
            child: Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.only(top: 140.0, left: 50),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hallo Hannah',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 38,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                        )
                    ),
                    Text('schön dich wieder zu sehen',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 23,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                          height: 0.9,
                        )
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 100),
                      child: Text('Name Lohmann',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text('Vorname Hannah',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text('E-Mail hannah@web.de',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),*/
        ],
      ),
    );
  }
}

