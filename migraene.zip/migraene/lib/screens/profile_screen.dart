import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment(-1, 1),
                end: Alignment(1, -1),
                colors: <Color>[
                  Color(0xff90f9ff),
                  Color(0xff9df4ff),
                  Color(0xffb9edff),
                  Color(0xffd7e5ff),
                  Color(0xffefdeff),
                  Color(0xffffdaf6),
                ],
              ),
            ),
          ),
          Container(
            width: 400,
            child: Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.only(top: 140.0, left: 50),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hallo Hannah',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 38,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                        )
                    ),
                    Text('schön dich wieder zu sehen',
                        style: TextStyle(
                          fontFamily: 'Poppins-Thin',
                          fontSize: 23,
                          color: Color(0xFF000000),
                          fontWeight: FontWeight.bold,
                          height: 0.9,
                        )
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 100),
                      child: Text('Name Lohmann',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text('Vorname Hannah',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text('E-Mail hannah@web.de',
                          style: TextStyle(
                            fontFamily: 'Poppins-Thin',
                            fontSize: 23,
                            color: Color(0xFF000000),
                            fontWeight: FontWeight.bold,
                            height: 0.9,
                          )
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

